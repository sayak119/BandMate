Bash scripts to create mp3's from midi files in the given directory. This will not overrite mp3 files with the appropriate name.
