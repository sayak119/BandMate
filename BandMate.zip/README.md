## Band Mate

Your band can't always be there with you when you want to practice. For individual and bands, we bring Band Mate. They can use it to practice their music at various tempos and keys. Use Alexa to help you practice and learn various keys and at various tempos.

## Steps to mkae your own such skill

* cd js

* npm install

* zip -r ../audio-player.zip *

* Upload zip file into AWS Lambda function, then build Alexa Skill project from Amazon Developer console.

* Then open developer.amazon.com

* Add the intents and utterances and enable Audio Player in Interface

* Complete the skill making process.
